import linecache
import banking

counter = 3;

def checkbal():
    ac = raw_input("Please enter your account number:")
    pin = raw_input("Please enter your pin number:")
    loc = "/Users/krishna/Desktop/Bank/"
    finloc = loc+str(ac)
    fo3 = open(finloc,'r+')
    if int(fo3.readline()) == int(pin):
        print "Welcome",fo3.readline()
        # getting the 5th line from the file which is balance of the user
        line = linecache.getline(finloc, 5)
        print "Your Current Balance is:",line
    else:
        print"Wrong pin Number, Try again!"
        # Mechanism to check if the user has typed the pin wrong for more than 3 times.
        if counter>0:
            checkbal()
            global counter
            counter = counter - 1
        else:
            print"Sorry u have typed your pin wrong more than 3 times"
            exit()

    ex = int(raw_input("Do you want to exit? 1. Yes , 2. No"))
    if(ex==1):
        print "Have a nice day!"
        exit()
    else:
        banking.welcome_page()