import linecache
import banking

counter = 3;

def deposit():
    ac = raw_input("Please enter your account number")
    pin = raw_input("Please enter your pin number")
    loc = "/Users/krishna/Desktop/Bank/"
    finloc = loc+str(ac)
    fo3 = open(finloc,'r')

    if int(fo3.readline()) == int(pin):
        print "Welcome",fo3.readline()
        line = linecache.getline(finloc, 5)
        print "Your Current Balance is:",line
        wi = float(raw_input("How much do you want to deposit today?"))
        bal = str(float(line) + wi)
        if float(wi) <= 0.0:
            print"You cannot deposit less than or equal to 0"
            deposit()
        fo3.seek(0,0)
        lines = fo3.readlines()
        fo3.close()
        fo4 = open(finloc,'w')
        i =0
        for line in lines:
            i=i+1
            if i<5:
                fo4.writelines(line)
            else :
                fo4.writelines(bal)

        fo4.close()
    else:
        print"Wrong pin Number, Try again!"
        if counter > 0:
            deposit()
            global counter
            counter = counter - 1
        else:
            print"Sorry u have typed your pin wrong more than 3 times"
            exit()


    ex = int(raw_input("Do you want to exit? 1. Yes , 2. No"))
    if(ex==1):
        print "Have a nice day!"
        exit()
    else:
        banking.welcome_page()



