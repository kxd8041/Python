import random
import banking
ac = 0

def create_account():
    print"Please enter your details:"
    name=raw_input("Name:")
    ad=raw_input("Address:")
    ph =raw_input("Contact number:")
    ph = ph.replace("-","")
    # cheking for validity of the phone number
    if len(ph) != 10:
        print "Not a valid US phone number! eg: 3104671146"
        create_account()
    bal = float(raw_input("Amount of money you want to deposit today:"))
    ac = random.randrange(10000, 100000)
    pin = random.randint(1000, 9999)
    print "Your account number is:", ac
    print "Your Pin number is:", pin
    loc = "/Users/krishna/Desktop/Bank/"
    finloc = loc + str(ac)
    fo = open(finloc, "wb")
    fo.write(str(pin))
    fo.write("\n")
    fo.write(name)
    fo.write("\n")
    fo.write(ad)
    fo.write("\n")
    fo.write(str(ph))
    fo.write("\n")
    fo.write(str(bal))
    fo.close()
    print " "
    print "Thank you for choosing our Bank"
    ex = int(raw_input("Do you want to exit? 1. Yes , 2. No"))
    if (ex == 1):
        print "Have a nice day!"
        exit()
    else:
        banking.welcome_page()


