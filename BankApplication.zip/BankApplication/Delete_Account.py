import os
import banking

def dele():
    ac = raw_input("Please enter your account number")
    pin = raw_input("Please enter your pin number")
    loc = "/Users/krishna/Desktop/Bank/"
    finloc = loc+str(ac)
    fo3 = open(finloc,'r+')
    if int(fo3.readline()) == int(pin):
        os.remove(finloc)
        print("Thank you for being our customer")
        print("Your account has been deleted")
    else:
        print"Wrong pin Number, Try again!"
    ex = int(raw_input("Do you want to exit? 1. Yes , 2. No"))
    if (ex == 1):
        print "Have a nice day!"
        exit()
    else:
        banking.welcome_page()

